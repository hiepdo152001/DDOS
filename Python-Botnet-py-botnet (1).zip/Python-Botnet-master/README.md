<p align="center">
  <img src="https://github.com/MayankFawkes/Python-Botnet/raw/master/Banner.png">
</p>

# Python-Botnet (UDP Flood)

This is simple ddos python botnet script for education purpose.

# Server-Commands
```
attack udp <ip> <port> <time in second> <thread>
Options:
	ping			To check server alive or not
	kill			To stop all servers
	list			Show online servers
	update			To update the clients list
	exit or quit 	For quiting/exiting
```
# Update
## 16/01/2021
* bug fixxed

# Notice
This is just a sample project and i will be not responsible for any of your actions.
